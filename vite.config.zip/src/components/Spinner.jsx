export default function Spinner() {
  return (
    <div className="flex justify-center py-16" role="status" aria-label="Memuat data">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-indigo-200 border-t-indigo-600" />
    </div>
  );
}